const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { GoogleAuth } = require('google-auth-library');
const fetch = require('node-fetch');

const app = express();

app.use(cors({
  origin: 'https://mattyflexx.github.io',
}));
app.use(bodyParser.json({ limit: '2mb' }));

// Health check route
app.get('/', (req, res) => {
  res.send('Imagen proxy server is up!');
});

// Imagen proxy route
app.post('/generate', async (req, res) => {
  try {
    const prompt = req.body.prompt;
    if (!prompt) {
      res.status(400).json({ error: 'Missing prompt in request body.' });
      return;
    }

    const PROJECT_ID = 'cardboard-capitalist';
    const LOCATION = 'us-central1';
    const MODEL = 'imagen-4.0-ultra-generate-preview-06-06';

    const endpoint = `https://${LOCATION}-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/${LOCATION}/publishers/google/models/${MODEL}:predict`;

    const auth = new GoogleAuth({ scopes: 'https://www.googleapis.com/auth/cloud-platform' });
    const client = await auth.getClient();
    const accessToken = await client.getAccessToken();

    const body = {
      instances: [{ prompt }]
    };

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken.token || accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const error = await response.text();
      res.status(response.status).json({ error });
      return;
    }

    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});